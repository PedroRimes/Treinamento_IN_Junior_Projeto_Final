<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '5vi7aAjff5562USHDdf8A+f9p9bMHJ2SN58zIrUCCsKc48OGZolqg3KH8BQYDw3SPfw7+DWop9V5GMiCm+Lz9Q==');
define('SECURE_AUTH_KEY',  'dunu28n6vmmO7VA0U63Y/z7duf6fUAQodW0YwGHmY0DIfwxOrh7vV7gOprePyaYCDYnu6vL4ANjupbQBwSkosQ==');
define('LOGGED_IN_KEY',    'cuDNqCNK1dR6Bdws9aqxOR2BTv6kpUa7xkg96WZVV89OzChL1eyMGLhA+G1P31d3PIRSqQmaGns1zEtigNiVcA==');
define('NONCE_KEY',        'FJXWas/QuVa5Al+/FMs/PwDS+jcMk505bqO2z6QmzsM1T+6ogOkFTi48GIhwJoNQMJi+w1CiVxLDcbK0N08UPQ==');
define('AUTH_SALT',        'TpnMLmnz3JUtu1AJ9K6w+nqkYhH/lIW4jVzJR0B+nSMUzaACTfOT8/huEGhWoP1Oz9/CookbDgtSV6lchaAKYA==');
define('SECURE_AUTH_SALT', 'P3QteNB+pKWiLr5j20s+G2Irv9kme7luU7DsYca08EJg6I+F4L9QkN56g3VEj4v4TfjY4VlZ+hor4ngDp7vehQ==');
define('LOGGED_IN_SALT',   'bxpUFr2Zw+4V+nEoXPqcZspwUvKXmqfotKqKGhgN0B4UdklHx2rXAj2MWkMe7greh6REPDHyLOF25PZat7QXLw==');
define('NONCE_SALT',       'aKvnWOC+71nHmF+OQhu5OfLnavko3OMwAQ1cpYtsb+H29fHcAVoAiL5tUBhJuYnvjS19o/PgQIflhD3o2Md+8w==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
